---
name: Feature Request
about: Suggest an idea for this project

---

# Feature Request

## I confirm:
- [ ] that I haven't found another request for this feature.
- [ ] that I have checked whether there are updates for my system available that
      contain this feature already.

## Description <!-- What do you want to be added? -->

## Justification [optional] <!-- Why integration in Proton instead of Wine? -->

## Risks [optional]

## References [optional] <!-- Which issues are related? -->
