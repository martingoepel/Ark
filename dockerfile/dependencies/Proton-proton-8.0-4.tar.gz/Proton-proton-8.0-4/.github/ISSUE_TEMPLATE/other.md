---
name: Other
about: No other issue template makes sense

---

<!--
Please always mention the Proton version and the titles of any games you are seeing an issue with.
-->
