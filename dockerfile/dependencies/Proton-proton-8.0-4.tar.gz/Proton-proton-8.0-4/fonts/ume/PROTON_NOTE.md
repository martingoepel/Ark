# UmeFont (version 670)

https://osdn.net/projects/ume-font/

## Fonts

https://osdn.net/projects/ume-font/downloads/22212/umefont_670.tar.xz/

- ume-tgo4.ttf: Ume Gothic
- ume-pgo4.ttf: Ume P Gothic
- ume-ugo4.ttf: Ume UI Gothic

## License

See license.html for details.

## Why UmeFont?

UmeFont is metric-compatible fonts with MS Japanese fonts.

https://wiki.archlinux.org/title/Metric-compatible_fonts#Ume
