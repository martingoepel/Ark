extern int cppISteamApps_STEAMAPPS_INTERFACE_VERSION001_GetAppData(void *, AppId_t, const char *, char *, int);
