extern EGCResults cppISteamGameCoordinator_SteamGameCoordinator001_SendMessage(void *, uint32, const void *, uint32);
extern bool cppISteamGameCoordinator_SteamGameCoordinator001_IsMessageAvailable(void *, uint32 *);
extern EGCResults cppISteamGameCoordinator_SteamGameCoordinator001_RetrieveMessage(void *, uint32 *, void *, uint32, uint32 *);
