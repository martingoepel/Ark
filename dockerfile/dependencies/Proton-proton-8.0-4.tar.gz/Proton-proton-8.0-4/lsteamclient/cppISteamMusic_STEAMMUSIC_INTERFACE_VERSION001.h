extern bool cppISteamMusic_STEAMMUSIC_INTERFACE_VERSION001_BIsEnabled(void *);
extern bool cppISteamMusic_STEAMMUSIC_INTERFACE_VERSION001_BIsPlaying(void *);
extern AudioPlayback_Status cppISteamMusic_STEAMMUSIC_INTERFACE_VERSION001_GetPlaybackStatus(void *);
extern void cppISteamMusic_STEAMMUSIC_INTERFACE_VERSION001_Play(void *);
extern void cppISteamMusic_STEAMMUSIC_INTERFACE_VERSION001_Pause(void *);
extern void cppISteamMusic_STEAMMUSIC_INTERFACE_VERSION001_PlayPrevious(void *);
extern void cppISteamMusic_STEAMMUSIC_INTERFACE_VERSION001_PlayNext(void *);
extern void cppISteamMusic_STEAMMUSIC_INTERFACE_VERSION001_SetVolume(void *, float);
extern float cppISteamMusic_STEAMMUSIC_INTERFACE_VERSION001_GetVolume(void *);
