extern uint32 cppISteamAppList_STEAMAPPLIST_INTERFACE_VERSION001_GetNumInstalledApps(void *);
extern uint32 cppISteamAppList_STEAMAPPLIST_INTERFACE_VERSION001_GetInstalledApps(void *, AppId_t *, uint32);
extern int cppISteamAppList_STEAMAPPLIST_INTERFACE_VERSION001_GetAppName(void *, AppId_t, char *, int);
extern int cppISteamAppList_STEAMAPPLIST_INTERFACE_VERSION001_GetAppInstallDir(void *, AppId_t, char *, int);
extern int cppISteamAppList_STEAMAPPLIST_INTERFACE_VERSION001_GetAppBuildId(void *, AppId_t);
