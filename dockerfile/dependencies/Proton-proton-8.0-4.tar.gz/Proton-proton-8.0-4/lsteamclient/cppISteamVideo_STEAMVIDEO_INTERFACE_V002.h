extern void cppISteamVideo_STEAMVIDEO_INTERFACE_V002_GetVideoURL(void *, AppId_t);
extern bool cppISteamVideo_STEAMVIDEO_INTERFACE_V002_IsBroadcasting(void *, int *);
extern void cppISteamVideo_STEAMVIDEO_INTERFACE_V002_GetOPFSettings(void *, AppId_t);
extern bool cppISteamVideo_STEAMVIDEO_INTERFACE_V002_GetOPFStringForApp(void *, AppId_t, char *, int32 *);
