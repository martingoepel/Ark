extern uint32 cppISteamAppTicket_STEAMAPPTICKET_INTERFACE_VERSION001_GetAppOwnershipTicketData(void *, uint32, void *, uint32, uint32 *, uint32 *, uint32 *, uint32 *);
