extern void cppISteamVideo_STEAMVIDEO_INTERFACE_V001_GetVideoURL(void *, AppId_t);
extern bool cppISteamVideo_STEAMVIDEO_INTERFACE_V001_IsBroadcasting(void *, int *);
